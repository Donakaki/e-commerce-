import React, { useState } from 'react';
import { 
  AlertTriangle, 
  BarChart3, 
  Bell,
  Clock,
  DollarSign,
  ShieldAlert,
  UserX,
  Activity,
  MapPin,
  CreditCard,
  Users,
  Search,
  Filter,
  ChevronDown
} from 'lucide-react';

// Mock data for demonstration
const recentAlerts = [
  { 
    id: 1, 
    type: 'High-risk Transaction', 
    amount: 2499.99, 
    location: 'Moscow, Russia', 
    time: '2 minutes ago',
    riskScore: 89,
    status: 'pending',
    cardType: 'Visa',
    cardLast4: '4532'
  },
  { 
    id: 2, 
    type: 'Multiple Failed Logins', 
    user: 'john.doe@example.com', 
    time: '15 minutes ago',
    riskScore: 75,
    status: 'investigating',
    location: 'Multiple Locations',
    attempts: 5
  },
  { 
    id: 3, 
    type: 'Unusual Activity', 
    amount: 999.99, 
    location: 'Lagos, Nigeria', 
    time: '1 hour ago',
    riskScore: 92,
    status: 'blocked',
    cardType: 'Mastercard',
    cardLast4: '8876'
  },
];

const metrics = {
  fraudRate: 2.4,
  suspiciousTransactions: 47,
  totalAmount: 15799.99,
  averageResponseTime: 1.2,
  activeUsers: 1243,
  blockedAccounts: 23
};

const riskDistribution = {
  high: 15,
  medium: 32,
  low: 53
};

function App() {
  const [activeTab, setActiveTab] = useState('dashboard');
  const [searchQuery, setSearchQuery] = useState('');

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-white shadow-sm">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4">
          <div className="flex justify-between items-center">
            <div className="flex items-center">
              <ShieldAlert className="h-8 w-8 text-indigo-600" />
              <h1 className="ml-2 text-2xl font-bold text-gray-900">FraudGuard</h1>
            </div>
            <div className="flex items-center space-x-4">
              <div className="relative">
                <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                  <Search className="h-5 w-5 text-gray-400" />
                </div>
                <input
                  type="text"
                  placeholder="Search transactions..."
                  className="block w-full pl-10 pr-3 py-2 border border-gray-300 rounded-md leading-5 bg-white placeholder-gray-500 focus:outline-none focus:placeholder-gray-400 focus:ring-1 focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm"
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                />
              </div>
              <button className="relative p-2 rounded-full hover:bg-gray-100">
                <Bell className="h-6 w-6 text-gray-500" />
                <span className="absolute top-0 right-0 block h-2 w-2 rounded-full bg-red-400 ring-2 ring-white"></span>
              </button>
            </div>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Navigation Tabs */}
        <div className="mb-8 border-b border-gray-200">
          <nav className="-mb-px flex space-x-8">
            {['Dashboard', 'Transactions', 'Users', 'Rules', 'Analytics'].map((tab) => (
              <button
                key={tab}
                className={`
                  whitespace-nowrap pb-4 px-1 border-b-2 font-medium text-sm
                  ${activeTab === tab.toLowerCase()
                    ? 'border-indigo-500 text-indigo-600'
                    : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'}
                `}
                onClick={() => setActiveTab(tab.toLowerCase())}
              >
                {tab}
              </button>
            ))}
          </nav>
        </div>

        {/* Metrics Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
          <MetricCard
            title="Fraud Rate"
            value={`${metrics.fraudRate}%`}
            icon={<BarChart3 className="h-6 w-6 text-indigo-600" />}
            trend="up"
            description="Last 30 days"
          />
          <MetricCard
            title="Suspicious Transactions"
            value={metrics.suspiciousTransactions}
            icon={<AlertTriangle className="h-6 w-6 text-yellow-500" />}
            trend="down"
            description="Pending review"
          />
          <MetricCard
            title="At Risk Amount"
            value={`$${metrics.totalAmount.toLocaleString()}`}
            icon={<DollarSign className="h-6 w-6 text-green-500" />}
            trend="up"
            description="Total value"
          />
          <MetricCard
            title="Avg. Response Time"
            value={`${metrics.averageResponseTime}m`}
            icon={<Clock className="h-6 w-6 text-blue-500" />}
            trend="down"
            description="Time to resolution"
          />
        </div>

        {/* Risk Distribution */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 mb-8">
          <div className="bg-white rounded-lg shadow col-span-2">
            <div className="px-6 py-4 border-b border-gray-200">
              <h2 className="text-lg font-medium text-gray-900">Risk Distribution</h2>
            </div>
            <div className="p-6">
              <div className="h-4 bg-gray-200 rounded-full overflow-hidden">
                <div
                  className="h-full bg-red-500"
                  style={{ width: `${riskDistribution.high}%` }}
                ></div>
                <div
                  className="h-full bg-yellow-500"
                  style={{ width: `${riskDistribution.medium}%`, marginTop: '-16px' }}
                ></div>
                <div
                  className="h-full bg-green-500"
                  style={{ width: `${riskDistribution.low}%`, marginTop: '-16px' }}
                ></div>
              </div>
              <div className="mt-4 flex justify-between text-sm">
                <div className="flex items-center">
                  <span className="h-3 w-3 bg-red-500 rounded-full mr-2"></span>
                  <span>High Risk ({riskDistribution.high}%)</span>
                </div>
                <div className="flex items-center">
                  <span className="h-3 w-3 bg-yellow-500 rounded-full mr-2"></span>
                  <span>Medium Risk ({riskDistribution.medium}%)</span>
                </div>
                <div className="flex items-center">
                  <span className="h-3 w-3 bg-green-500 rounded-full mr-2"></span>
                  <span>Low Risk ({riskDistribution.low}%)</span>
                </div>
              </div>
            </div>
          </div>

          <div className="bg-white rounded-lg shadow">
            <div className="px-6 py-4 border-b border-gray-200">
              <h2 className="text-lg font-medium text-gray-900">Account Status</h2>
            </div>
            <div className="p-6">
              <div className="flex items-center justify-between mb-4">
                <div className="flex items-center">
                  <Users className="h-5 w-5 text-gray-400 mr-2" />
                  <span className="text-sm text-gray-600">Active Users</span>
                </div>
                <span className="text-lg font-semibold">{metrics.activeUsers}</span>
              </div>
              <div className="flex items-center justify-between">
                <div className="flex items-center">
                  <UserX className="h-5 w-5 text-gray-400 mr-2" />
                  <span className="text-sm text-gray-600">Blocked Accounts</span>
                </div>
                <span className="text-lg font-semibold">{metrics.blockedAccounts}</span>
              </div>
            </div>
          </div>
        </div>

        {/* Recent Alerts */}
        <div className="bg-white rounded-lg shadow">
          <div className="px-6 py-4 border-b border-gray-200 flex justify-between items-center">
            <h2 className="text-lg font-medium text-gray-900">Recent Alerts</h2>
            <button className="flex items-center text-sm text-gray-500 hover:text-gray-700">
              <Filter className="h-4 w-4 mr-1" />
              Filter
              <ChevronDown className="h-4 w-4 ml-1" />
            </button>
          </div>
          <div className="divide-y divide-gray-200">
            {recentAlerts.map((alert) => (
              <div key={alert.id} className="px-6 py-4">
                <div className="flex items-center justify-between">
                  <div className="flex items-center">
                    <div className={`
                      p-2 rounded-full
                      ${alert.status === 'pending' ? 'bg-yellow-100' : 
                        alert.status === 'investigating' ? 'bg-blue-100' : 
                        'bg-red-100'}
                    `}>
                      <AlertTriangle className={`
                        h-5 w-5
                        ${alert.status === 'pending' ? 'text-yellow-500' : 
                          alert.status === 'investigating' ? 'text-blue-500' : 
                          'text-red-500'}
                      `} />
                    </div>
                    <div className="ml-3">
                      <p className="text-sm font-medium text-gray-900">{alert.type}</p>
                      <div className="flex items-center mt-1">
                        <MapPin className="h-4 w-4 text-gray-400 mr-1" />
                        <p className="text-sm text-gray-500">
                          {alert.location}
                        </p>
                        {alert.cardType && (
                          <>
                            <CreditCard className="h-4 w-4 text-gray-400 ml-3 mr-1" />
                            <p className="text-sm text-gray-500">
                              {alert.cardType} ending in {alert.cardLast4}
                            </p>
                          </>
                        )}
                      </div>
                    </div>
                  </div>
                  <div className="flex items-center">
                    <div className="mr-6">
                      <p className="text-sm text-gray-500">{alert.time}</p>
                      <p className={`
                        text-sm font-medium mt-1
                        ${alert.riskScore >= 90 ? 'text-red-600' :
                          alert.riskScore >= 70 ? 'text-yellow-600' :
                          'text-green-600'}
                      `}>
                        Risk Score: {alert.riskScore}
                      </p>
                    </div>
                    <button className="px-3 py-1 rounded-md text-sm font-medium text-white bg-indigo-600 hover:bg-indigo-700">
                      Review
                    </button>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </main>
    </div>
  );
}

function MetricCard({ title, value, icon, trend, description }) {
  return (
    <div className="bg-white rounded-lg shadow p-6">
      <div className="flex items-center justify-between">
        <div>
          <p className="text-sm font-medium text-gray-600">{title}</p>
          <p className="mt-2 text-3xl font-semibold text-gray-900">{value}</p>
        </div>
        {icon}
      </div>
      <div className="mt-4 flex items-center">
        <Activity className={`h-4 w-4 ${trend === 'up' ? 'text-red-500' : 'text-green-500'}`} />
        <span className={`ml-2 text-sm ${trend === 'up' ? 'text-red-500' : 'text-green-500'}`}>
          {trend === 'up' ? '+2.5%' : '-1.8%'}
        </span>
        <span className="ml-2 text-sm text-gray-500">{description}</span>
      </div>
    </div>
  );
}

export default App;